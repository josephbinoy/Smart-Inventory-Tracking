# Smart Inventory Tracking > 2024-05-27 8:05pm
https://universe.roboflow.com/inventory-tracking/smart-inventory-tracking

Provided by a Roboflow user
License: CC BY 4.0

